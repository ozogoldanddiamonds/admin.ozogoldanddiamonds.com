import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CategoryService } from '../../Services/category.service';
import { Category } from '../../Models/Category';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmationComponent } from 'src/app/delete-confirmation/delete-confirmation.component';
import { ViewCategoryComponent } from 'src/app/View-dialog-Controllers/view-category/view-category.component';


@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

displayedColumns: string[] = ['sno', 'name', 'image', 'isActive', 'actions'];
dataSource = new MatTableDataSource<Category>();

  categories: Category[] = [];
  selectedCategory: Category | null = null;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private categoryService: CategoryService, private router: Router,  private dialog: MatDialog,
) {}

  ngOnInit(): void {
    this.getAllCategories();
  }

  // Controller method
getAllCategories(): void {
  this.categoryService.getAllCategories().subscribe({
    next: (response: any) => {
      console.log('API Response:', response);

      this.categories = response.data;
      this.dataSource.data = response.data;

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },
    error: (error) => {
      console.error('Error fetching categories:', error);
    }
  });
}

goToCreateCategory() {
  this.router.navigate([
    '/create-category'
  ]);
}

editCategory(element: any) {
  this.router.navigate([
    '/admin/update-category',
    element._id
  ]);
}
viewCategory(
  category: Category
): void {

  this.dialog.open(
    ViewCategoryComponent,
    {
      width: '500px',
      data: category
    }
  );
}

deleteCategory(data: any) {

  const dialogRef =
    this.dialog.open(
DeleteConfirmationComponent,      {
        width: '400px'
      }
    );

  dialogRef.afterClosed()
    .subscribe(result => {

      if (result) {

        this.categoryService
          .deleteCategory(data._id)
          .subscribe({

            next: () => {
              alert("Deleted successfully");
              this.getAllCategories();
            },

            error: () => {
              alert("Delete failed");
            }

          });
      }

    });
}
  // Search Filter
  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}