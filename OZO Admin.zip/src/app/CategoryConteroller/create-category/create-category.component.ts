import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/Services/category.service';

@Component({
  selector: 'app-create-category',
  templateUrl: './create-category.component.html',
  styleUrls: ['./create-category.component.css']
})
export class CreateCategoryComponent implements OnInit {

  categoryForm!: FormGroup;

  selectedFile:
    File | null = null;

  imagePreview:
    string | ArrayBuffer | null = null;

  constructor(
    private fb:
      FormBuilder,

    public _categoryService:
      CategoryService,

    public router:
      Router,

    public snackBar:
      MatSnackBar
  ) {}

  ngOnInit(): void {
    this.categoryForm =
      this.fb.group({
        name: [
          '',
          [
            Validators.required,
            Validators.minLength(3)
          ]
        ],
        image: [
          '',
          Validators.required
        ],
        isActive: [true]
      });
  }


  onFileChange(
    event: any
  ) {
    if (
      event.target.files &&
      event.target.files.length > 0
    ) {
      const file =
        event.target.files[0];

      this.selectedFile =
        file;

      const reader =
        new FileReader();

      reader.onload = () => {
        this.imagePreview =
          reader.result;
      };

      reader.readAsDataURL(
        file
      );

      this.categoryForm.patchValue({
        image: file
      });
    }
  }


  onSubmit() {
    if (
      this.categoryForm.valid
    ) {
      const formData =
        new FormData();

      formData.append(
        'name',
        this.categoryForm.value.name
      );

      formData.append(
        'isActive',
        this.categoryForm.value.isActive
      );

      if (
        this.selectedFile
      ) {
        formData.append(
          'image',
          this.selectedFile
        );
      }

      this._categoryService
        .createCategory(
          formData
        )
        .subscribe({
          next: (response) => {
            console.log(
              'Category created successfully',
              response
            );

            this.snackBar.open(
              'Category created successfully',
              'Close',
              {
                duration: 3000,
                horizontalPosition:
                  'center',
                verticalPosition:
                  'top'
              }
            );

            this.router.navigate([
  '/admin/category'
]);

            this.categoryForm.reset();
          },

          error: (err) => {
            console.error(
              'Failed to create category',
              err
            );

            this.snackBar.open(
              'Failed to create category',
              'Close',
              {
                duration: 3000,
                horizontalPosition:
                  'center',
                verticalPosition:
                  'top'
              }
            );
          }
        });
    }
  }


  cancelUpdate() {
    this.router.navigate([
      '/dashboard/category'
    ]);
  }


  goBack() {
     this.router.navigate([
    '/admin/category'
  ]);
  }
}