export interface Variant {
  size?: string;
  weight?: number;
  makingCharges?: number;
  diamondPrice?: number;
  basePrice?: number;
  discountPercentage?: number;
  stock?: number;
}

export interface Product {
  _id?: string;

  name: string;

  description?: string;

  category?: any;

  subCategory?: any;

  subSubCategory?: any;

  productType: 'GOLD' | 'DIAMOND';

  variants: Variant[];

  images?: string[];

  isActive?: boolean;

  createdAt?: string;

  updatedAt?: string;
}