import { CdkTableDataSourceInput } from '@angular/cdk/table';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { DeleteConfirmationComponent } from 'src/app/delete-confirmation/delete-confirmation.component';
import { ProductService } from 'src/app/Services/product.service';
import { ViewProductComponent } from 'src/app/View-dialog-Controllers/view-product/view-product.component';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  displayedColumns: string[] = [
    'sno',
    'name',
    'category',
    'subCategory',
    'subSubCategory',
    'productType',
    'variants',
    'image',
    'isActive',
    'actions'
  ];

  dataSource =
    new MatTableDataSource<any>();

  products:
    any[] = [];

  selectedProduct:
    any = null;

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;

  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(
    private productService:
      ProductService,

    private router:
      Router,

    private dialog:
      MatDialog
  ) {}

  ngOnInit(): void {
    this.getAllProducts();
  }

  /*
  GET ALL PRODUCTS
  */
  getAllProducts() {
    this.productService
      .getAllProducts()
      .subscribe({
        next: (response: any) => {
          console.log(
            'Products:',
            response
          );

          this.products =
            response.data;

          this.dataSource.data =
            response.data;

          this.dataSource.paginator =
            this.paginator;

          this.dataSource.sort =
            this.sort;
        },

        error: (error) => {
          console.error(
            'Error fetching products:',
            error
          );
        }
      });
  }

  /*
  CREATE PAGE
  */
  goToCreateProduct() {
    this.router.navigate([
      '/admin/create-product'
    ]);
  }

  /*
  EDIT PRODUCT
  */
  editProduct(
    element: any
  ) {
    this.router.navigate([
      '/admin/update-product',
      element._id
    ]);
  }

  /*
  VIEW PRODUCT
  */
  viewProduct(
  product: any
): void {

  this.dialog.open(
    ViewProductComponent,
    {
      width: '900px',
      data: product
    }
  );
}
  /*
  DELETE PRODUCT
  */
  deleteProduct(
    data: any
  ) {
    const dialogRef =
      this.dialog.open(
        DeleteConfirmationComponent,
        {
          width: '400px'
        }
      );

    dialogRef.afterClosed()
      .subscribe(result => {

        if (result === true) {

          this.productService
            .deleteProduct(
              data._id
            )
            .subscribe({

              next: () => {
                alert(
                  "Deleted successfully"
                );

                this.getAllProducts();
              },

              error: () => {
                alert(
                  "Delete failed"
                );
              }

            });
        }

      });
  }

  /*
  SEARCH FILTER
  */
  applyFilter(
    event: Event
  ): void {
    const filterValue =
      (event.target as HTMLInputElement)
      .value;

    this.dataSource.filter =
      filterValue
        .trim()
        .toLowerCase();
  }

}
