import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/Services/category.service';
import { ProductService } from 'src/app/Services/product.service';
import { SubcategoryService } from 'src/app/Services/subcategory.service';
import { SubsubcategoryService } from 'src/app/Services/subsubcategory.service';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {

  productForm!: FormGroup;

  categories: any[] = [];
  subCategories: any[] = [];
  subSubCategories: any[] = [];

  imagePreviews: string[] = [];

  constructor(
    private fb:
      FormBuilder,

    private categoryService:
      CategoryService,

    private subCategoryService:
      SubcategoryService,

    private subSubCategoryService:
      SubsubcategoryService,

    private productService:
      ProductService,

    private router:
      Router
  ) {}

  ngOnInit(): void {

    this.productForm =
      this.fb.group({

        name: [
          '',
          Validators.required
        ],

        description: [''],

        category: [
          '',
          Validators.required
        ],

        subCategory: [
          '',
          Validators.required
        ],

        subSubCategory: [
          '',
          Validators.required
        ],

        productType: [
          '',
          Validators.required
        ],

        variants:
          this.fb.array([
            this.createVariant()
          ]),

        images:
          this.fb.array([]),

        isActive: [true]
      });

    this.getCategories();
    this.getSubCategories();
    this.getSubSubCategories();
  }

  /*
  VARIANT CREATE
  */
  createVariant(): FormGroup {
    return this.fb.group({
      size: [''],
      weight: [''],
      makingCharges: [0],
      diamondPrice: [0],
      basePrice: [0],
      discountPercentage: [0],
      stock: [0]
    });
  }

  /*
  GET VARIANTS
  */
  get variants():
    FormArray {
    return this.productForm.get(
      'variants'
    ) as FormArray;
  }

  /*
  GET IMAGES
  */
  get images():
    FormArray {
    return this.productForm.get(
      'images'
    ) as FormArray;
  }

  /*
  ADD VARIANT
  */
  addVariant() {
    this.variants.push(
      this.createVariant()
    );
  }

  /*
  REMOVE VARIANT
  */
  removeVariant(
    index: number
  ) {
    this.variants.removeAt(
      index
    );
  }

  /*
  ADD IMAGE FIELD
  */
  addImage() {
    this.images.push(
      this.fb.control(
        null,
        Validators.required
      )
    );
  }

  /*
  REMOVE IMAGE FIELD
  */
  removeImage(
    index: number
  ) {
    this.images.removeAt(
      index
    );

    this.imagePreviews.splice(
      index,
      1
    );
  }

  /*
  IMAGE CHANGE
  */
  onFileChange(
    event: any,
    index: number
  ) {
    const file =
      event.target.files[0];

    if (file) {

      this.images
        .at(index)
        .setValue(file);

      const reader =
        new FileReader();

      reader.onload =
        (e: any) => {
          this.imagePreviews[index] =
            e.target.result;
        };

      reader.readAsDataURL(
        file
      );
    }
  }

  /*
  GET CATEGORIES
  */
  getCategories() {
    this.categoryService
      .getAllCategories()
      .subscribe({
        next: (response: any) => {
          this.categories =
            response.data;
        }
      });
  }

  /*
  GET SUBCATEGORIES
  */
  getSubCategories() {
    this.subCategoryService
      .getAllSubCategories()
      .subscribe({
        next: (response: any) => {
          this.subCategories =
            response.data;
        }
      });
  }

  /*
  GET SUBSUBCATEGORIES
  */
  getSubSubCategories() {
    this.subSubCategoryService
      .getAllSubSubCategories()
      .subscribe({
        next: (response: any) => {
          this.subSubCategories =
            response.data;
        }
      });
  }

  /*
  SUBMIT
  */
  onSubmit() {

    if (
      this.productForm.valid
    ) {

      const formData =
        new FormData();

      formData.append(
        'name',
        this.productForm.value.name
      );

      formData.append(
        'description',
        this.productForm.value.description
      );

      formData.append(
        'category',
        this.productForm.value.category
      );

      formData.append(
        'subCategory',
        this.productForm.value.subCategory
      );

      formData.append(
        'subSubCategory',
        this.productForm.value.subSubCategory
      );

      formData.append(
        'productType',
        this.productForm.value.productType
      );

      formData.append(
        'variants',
        JSON.stringify(
          this.productForm.value.variants
        )
      );

      formData.append(
        'isActive',
        this.productForm.value.isActive
      );

      // multiple images
      this.images.controls.forEach(
        (control: any) => {
          formData.append(
            'images',
            control.value
          );
        }
      );

      this.productService
        .createProduct(
          formData
        )
        .subscribe({
          next: (response) => {
            console.log(
              response
            );

            alert(
              'Product created successfully'
            );

            this.router.navigate([
              '/admin/product'
            ]);
          },

          error: (error) => {
            console.error(
              error
            );
          }
        });
    }
  }

  /*
  BACK
  */
  goBack() {
    this.router.navigate([
      '/admin/product'
    ]);
  }

}