import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoryService } from 'src/app/Services/category.service';
import { ProductService } from 'src/app/Services/product.service';
import { SubcategoryService } from 'src/app/Services/subcategory.service';
import { SubsubcategoryService } from 'src/app/Services/subsubcategory.service';

@Component({
  selector: 'app-product-update',
  templateUrl: './product-update.component.html',
  styleUrls: ['./product-update.component.css']
})
export class ProductUpdateComponent implements OnInit {

  productForm!: FormGroup;

  productId!: string;

  categories: any[] = [];
  subCategories: any[] = [];
  subSubCategories: any[] = [];

  imagePreviews: string[] = [];

  constructor(
    private fb:
      FormBuilder,

    private route:
      ActivatedRoute,

    private router:
      Router,

    private categoryService:
      CategoryService,

    private subCategoryService:
      SubcategoryService,

    private subSubCategoryService:
      SubsubcategoryService,

    private productService:
      ProductService
  ) {}

  ngOnInit(): void {

    this.productId =
      this.route.snapshot.paramMap.get(
        'id'
      )!;

    this.productForm =
      this.fb.group({

        name: [
          '',
          Validators.required
        ],

        description: [''],

        category: [
          '',
          Validators.required
        ],

        subCategory: [
          '',
          Validators.required
        ],

        subSubCategory: [
          '',
          Validators.required
        ],

        productType: [
          '',
          Validators.required
        ],

        variants:
          this.fb.array([]),

        images:
          this.fb.array([]),

        isActive: [true]
      });

    this.getCategories();
    this.getSubCategories();
    this.getSubSubCategories();

    this.getProductById();
  }

  /*
  CREATE VARIANT
  */
  createVariant(
    data?: any
  ): FormGroup {
    return this.fb.group({
      size: [
        data?.size || ''
      ],
      weight: [
        data?.weight || ''
      ],
      makingCharges: [
        data?.makingCharges || 0
      ],
      diamondPrice: [
        data?.diamondPrice || 0
      ],
      basePrice: [
        data?.basePrice || 0
      ],
      discountPercentage: [
        data?.discountPercentage || 0
      ],
      stock: [
        data?.stock || 0
      ]
    });
  }

  /*
  GET VARIANTS
  */
  get variants():
    FormArray {
    return this.productForm.get(
      'variants'
    ) as FormArray;
  }

  /*
  GET IMAGES
  */
  get images():
    FormArray {
    return this.productForm.get(
      'images'
    ) as FormArray;
  }

  /*
  GET PRODUCT BY ID
  */
  getProductById() {
    this.productService
      .getProductById(
        this.productId
      )
      .subscribe({
        next: (response: any) => {

          const product =
            response.data;

          // patch form
          this.productForm.patchValue({
            name:
              product.name,

            description:
              product.description,

            category:
              product.category?._id,

            subCategory:
              product.subCategory?._id,

            subSubCategory:
              product.subSubCategory?._id,

            productType:
              product.productType,

            isActive:
              product.isActive
          });

          // patch variants
          product.variants.forEach(
            (variant: any) => {
              this.variants.push(
                this.createVariant(
                  variant
                )
              );
            }
          );

          // patch images
          product.images.forEach(
            (img: string) => {

              this.images.push(
                this.fb.control(
                  img
                )
              );

              this.imagePreviews.push(
                img
              );
            }
          );
        },

        error: (error) => {
          console.error(
            error
          );
        }
      });
  }

  /*
  ADD VARIANT
  */
  addVariant() {
    this.variants.push(
      this.createVariant()
    );
  }

  /*
  REMOVE VARIANT
  */
  removeVariant(
    index: number
  ) {
    this.variants.removeAt(
      index
    );
  }

  /*
  ADD IMAGE
  */
  addImage() {
    this.images.push(
      this.fb.control(null)
    );

    this.imagePreviews.push('');
  }

  /*
  REMOVE IMAGE
  */
  removeImage(
    index: number
  ) {
    this.images.removeAt(
      index
    );

    this.imagePreviews.splice(
      index,
      1
    );
  }

  /*
  IMAGE CHANGE
  */
  onFileChange(
    event: any,
    index: number
  ) {
    const file =
      event.target.files[0];

    if (file) {

      this.images
        .at(index)
        .setValue(file);

      const reader =
        new FileReader();

      reader.onload =
        (e: any) => {
          this.imagePreviews[index] =
            e.target?.result;
        };

      reader.readAsDataURL(
        file
      );
    }
  }

  /*
  GET CATEGORIES
  */
  getCategories() {
    this.categoryService
      .getAllCategories()
      .subscribe({
        next: (res: any) => {
          this.categories =
            res.data;
        }
      });
  }

  /*
  GET SUBCATEGORIES
  */
  getSubCategories() {
    this.subCategoryService
      .getAllSubCategories()
      .subscribe({
        next: (res: any) => {
          this.subCategories =
            res.data;
        }
      });
  }

  /*
  GET SUBSUBCATEGORIES
  */
  getSubSubCategories() {
    this.subSubCategoryService
      .getAllSubSubCategories()
      .subscribe({
        next: (res: any) => {
          this.subSubCategories =
            res.data;
        }
      });
  }

  /*
  UPDATE PRODUCT
  */
  onSubmit() {

    if (
      this.productForm.valid
    ) {

      const formData =
        new FormData();

      formData.append(
        'name',
        this.productForm.value.name
      );

      formData.append(
        'description',
        this.productForm.value.description
      );

      formData.append(
        'category',
        this.productForm.value.category
      );

      formData.append(
        'subCategory',
        this.productForm.value.subCategory
      );

      formData.append(
        'subSubCategory',
        this.productForm.value.subSubCategory
      );

      formData.append(
        'productType',
        this.productForm.value.productType
      );

      formData.append(
        'variants',
        JSON.stringify(
          this.productForm.value.variants
        )
      );

      formData.append(
        'isActive',
        this.productForm.value.isActive
      );

      // old images
      const existingImages:
        string[] = [];

      this.images.controls.forEach(
        (control: any) => {

          // new image
          if (
            control.value
            instanceof File
          ) {
            formData.append(
              'images',
              control.value
            );
          }

          // old image url
          else if (
            typeof control.value
            === 'string'
          ) {
            existingImages.push(
              control.value
            );
          }
        }
      );

      // existing images send
      formData.append(
        'existingImages',
        JSON.stringify(
          existingImages
        )
      );

      this.productService
        .updateProduct(
          this.productId,
          formData
        )
        .subscribe({
          next: (
            response
          ) => {
            console.log(
              response
            );

            alert(
              'Product updated successfully'
            );

            this.router.navigate([
              '/admin/product'
            ]);
          },

          error: (
            error
          ) => {
            console.error(
              error
            );
          }
        });
    }
  }

  /*
  GO BACK
  */
  goBack() {
    this.router.navigate([
      '/admin/product'
    ]);
  }

}