import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from '../environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private apiUrl = environment.apiUrl;

  constructor(
    private http: HttpClient
  ) {}

  /*
  CREATE PRODUCT
  */
  createProduct(
    formData: FormData
  ): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/createProduct`,
      formData
    );
  }

  /*
  GET ALL PRODUCTS
  */
  getAllProducts():
    Observable<any> {
    return this.http.get(
      `${this.apiUrl}/getAllProducts`
    );
  }

  /*
  GET PRODUCT BY ID
  */
  getProductById(
    id: string
  ): Observable<any> {
    return this.http.get(
      `${this.apiUrl}/geyByIdproduct/${id}`
    );
  }

  /*
  UPDATE PRODUCT
  */
  updateProduct(
    id: string,
    formData: FormData
  ): Observable<any> {
    return this.http.put(
      `${this.apiUrl}/UpdateProduct/${id}`,
      formData
    );
  }

  /*
  DELETE PRODUCT
  */
  deleteProduct(
    id: string
  ): Observable<any> {
    return this.http.delete(
      `${this.apiUrl}/Deleteproduct/${id}`
    );
  }

}
