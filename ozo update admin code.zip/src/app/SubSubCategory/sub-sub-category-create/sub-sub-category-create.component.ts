import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/Services/alert.service';
import { CategoryService } from 'src/app/Services/category.service';
import { SubcategoryService } from 'src/app/Services/subcategory.service';
import { SubsubcategoryService } from 'src/app/Services/subsubcategory.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sub-sub-category-create',
  templateUrl: './sub-sub-category-create.component.html',
  styleUrls: ['./sub-sub-category-create.component.css']
})
export class SubSubCategoryCreateComponent implements OnInit {

  isSaving: boolean = false;

  subSubCategoryForm!: FormGroup;

  categories: any[] = [];

  subCategories: any[] = [];

  selectedFile:
    File | null = null;

  imagePreview:
    string | ArrayBuffer | null = null;


  constructor(

    private fb:
      FormBuilder,

    private categoryService:
      CategoryService,

    private subCategoryService:
      SubcategoryService,

    private subSubCategoryService:
      SubsubcategoryService,

    private router:
      Router,

    private alert:
      AlertService

  ) { }


  ngOnInit(): void {

    this.subSubCategoryForm =
      this.fb.group({

        name: [
          '',
          Validators.required
        ],

        category: [
          '',
          Validators.required
        ],

        subCategory: [
          '',
          Validators.required
        ],

        isActive: [true]

      });


    this.getCategories();

    this.getSubCategories();

  }


  onCategoryChange(
    event: any
  ): void {

    const categoryId =
      event.target.value;


    // RESET SUBCATEGORY

    this.subSubCategoryForm
      .patchValue({

        subCategory: ''

      });


    // API CALL

    this.subCategoryService
      .getSubCategoryByCategory(
        categoryId
      )
      .subscribe({

        next: (res: any) => {

          console.log(res);

          this.subCategories =
            res.data;

        },

        error: (err: any) => {

          console.log(err);

        }

      });

  }


  /*
  GET CATEGORY
  */

  getCategories() {

    this.categoryService
      .getAllCategories()
      .subscribe((res: any) => {

        this.categories =
          res.data;

      });

  }


  /*
  GET SUBCATEGORY
  */

  getSubCategories() {

    this.subCategoryService
      .getAllSubCategories()
      .subscribe((res: any) => {

        this.subCategories =
          res.data;

      });

  }


  /*
  IMAGE CHANGE
  */

  onFileChange(
    event: any
  ) {

    if (
      event.target.files &&
      event.target.files.length > 0
    ) {

      const file =
        event.target.files[0];


      this.selectedFile =
        file;


      const reader =
        new FileReader();


      reader.onload = () => {

        this.imagePreview =
          reader.result;

      };


      reader.readAsDataURL(
        file
      );

    }

  }


  /*
  SUBMIT
  */

  onSubmit() {

    // Show all validation messages
    this.subSubCategoryForm
      .markAllAsTouched();


    // Validation failed
    // Loading must remain OFF
    if (
      this.subSubCategoryForm.invalid
    ) {

      this.isSaving = false;

      return;

    }


    // All required fields valid
    // Start loading only before API call
    this.isSaving = true;


    const formData =
      new FormData();


    formData.append(
      'name',
      this.subSubCategoryForm.value.name
    );


    formData.append(
      'category',
      this.subSubCategoryForm.value.category
    );


    formData.append(
      'subCategory',
      this.subSubCategoryForm.value.subCategory
    );


    formData.append(
      'isActive',
      this.subSubCategoryForm.value.isActive
    );


    if (this.selectedFile) {

      formData.append(
        'image',
        this.selectedFile
      );

    }


    this.subSubCategoryService
      .createSubSubCategory(
        formData
      )
      .subscribe({

        // SUCCESS

        next: (response) => {

          console.log(response);


          // Stop loading
          this.isSaving = false;


          this.alert.success(
            'SubSubCategory Created Successfully'
          );


          this.router.navigate([
            '/admin/subsubcategory'
          ]);

        },


        // ERROR

        error: (err: any) => {

          console.log(
            'Create SubSubCategory Error:',
            err
          );


          // Stop loading
          this.isSaving = false;


          // Actual backend error message
          const backendMessage =
            err?.error?.message ||
            err?.error?.error ||
            err?.message ||
            'Something went wrong while creating SubSubCategory';


          this.alert.error(
            backendMessage
          );

        }

      });

  }


  goBack() {

    this.router.navigate([
      '/admin/subsubcategory'
    ]);

  }

}