import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import Swal from 'sweetalert2';
import { AlertService } from '../Services/alert.service';

@Component({
  selector: 'app-sub-branch-sidebar',
  templateUrl: './sub-branch-sidebar.component.html',
  styleUrls: ['./sub-branch-sidebar.component.css'],
})
export class SubBranchSidebarComponent {
  showProfilePopup = false;
  openMenu: string | null = null;

  role = localStorage.getItem('role') || '';


  isSidebarClosed = false;
  showDropdown = false;
  userName = localStorage.getItem('name') || 'Admin';
  userEmail = localStorage.getItem('email') || 'email@gmail.com';

  constructor(private router: Router, private alertService: AlertService) { }

  toggleSidebar() {
    this.isSidebarClosed = !this.isSidebarClosed;
  }
  toggleDropdown() {
    this.showDropdown = !this.showDropdown;
  }

  onMouseEnter() { }

  onMouseLeave() { }
  goToProfile() {

    this.showDropdown = false;

    // this.router.navigate(['SUB_BRANCH/Profile']);
    this.showProfilePopup = true;

  }
  toggleMenu(menu: string): void { if (this.openMenu === menu) { this.openMenu = null; } else { this.openMenu = menu; } }
  logout() {

    this.showDropdown = false;

    this.alertService.confirm(
      'Confirm Logout?',
      'Are you sure you want to logout?',
      'Logout',
      'Cancel'
    ).then((result: any) => {

      if (result.isConfirmed) {

        localStorage.clear();

        this.router.navigate(['/']);

      }

    });

  }



  closeProfile() {

    this.showProfilePopup = false;

  }


}